package com.silencio;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Silencio - um mod de terror psicologico, lento e silencioso.
 * Toda a logica roda no servidor (inclusive o servidor integrado do singleplayer).
 */
public class SilencioMod implements ModInitializer {

    public static final String MOD_ID = "silencio";
    private static final String GHOST = "Observador";

    public static SoundEvent DRONE;
    public static SoundEvent WHISPER;
    public static SoundEvent HEARTBEAT;
    public static SoundEvent KNOCK;

    private static final Random RNG = new Random();
    private static final Map<UUID, PlayerState> STATES = new HashMap<>();
    private static final Properties SAVED = new Properties();
    private static final List<Task> TASKS = new ArrayList<>();
    private static long tick = 0;
    private static boolean paused = false;

    private record Task(long due, Runnable run) {}

    private static class PlayerState {
        long ticks;
        long nextEvent;
        VillagerEntity watcher;
        int watcherAge;
        int grace;
        int lookTicks;
        boolean midnightDone;
        long lastSleepScare;
    }

    // ------------------------------------------------------------------ init

    @Override
    public void onInitialize() {
        DRONE = registerSound("drone");
        WHISPER = registerSound("whisper");
        HEARTBEAT = registerSound("heartbeat");
        KNOCK = registerSound("knock");

        loadSaved();

        ServerTickEvents.END_SERVER_TICK.register(SilencioMod::onTick);
        ServerLifecycleEvents.SERVER_STOPPING.register(SilencioMod::saveAll);

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) ->
                onChat(sender, message.getSignedContent()));

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            PlayerState st = state(p);
            st.watcher = null;
            if (!paused && stage(st) >= 2 && RNG.nextInt(100) < 35) {
                UUID id = p.getUuid();
                later(300 + RNG.nextInt(600), server, id, pl -> say(pl, pick(JOIN_LINES).replace("{n}", pl.getName().getString())));
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            PlayerState st = STATES.get(handler.player.getUuid());
            if (st != null) dropWatcher(st);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity sp && !paused && stage(state(sp)) >= 1) {
                MinecraftServer srv = sp.getServer();
                if (srv != null && RNG.nextInt(100) < 70) {
                    later(50 + RNG.nextInt(60), srv, sp.getUuid(), pl -> say(pl, pick(DEATH_LINES)));
                }
            }
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("silencio")
                        .then(CommandManager.literal("parar").executes(ctx -> {
                            paused = true;
                            for (PlayerState s : STATES.values()) dropWatcher(s);
                            ctx.getSource().sendFeedback(() -> Text.literal("Silencio pausado. Use /silencio retomar para continuar."), false);
                            return 1;
                        }))
                        .then(CommandManager.literal("retomar").executes(ctx -> {
                            paused = false;
                            ctx.getSource().sendFeedback(() -> Text.literal("Silencio retomado."), false);
                            return 1;
                        }))
                        .then(CommandManager.literal("teste").requires(src -> src.hasPermissionLevel(2))
                                .then(CommandManager.argument("n", StringArgumentType.word()).executes(ctx -> {
                                    ServerPlayerEntity pl = ctx.getSource().getPlayerOrThrow();
                                    int n;
                                    try {
                                        n = Integer.parseInt(StringArgumentType.getString(ctx, "n"));
                                    } catch (NumberFormatException e) {
                                        n = 0;
                                    }
                                    fireEvent(pl, state(pl), n);
                                    return 1;
                                })))));
    }

    private static SoundEvent registerSound(String name) {
        Identifier id = Identifier.of(MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    // ------------------------------------------------------------------ persistence

    private static Path savePath() {
        return FabricLoader.getInstance().getConfigDir().resolve("silencio.properties");
    }

    private static void loadSaved() {
        Path p = savePath();
        if (Files.exists(p)) {
            try (InputStream in = Files.newInputStream(p)) {
                SAVED.load(in);
            } catch (IOException ignored) {
            }
        }
    }

    private static void saveAll(MinecraftServer server) {
        for (Map.Entry<UUID, PlayerState> e : STATES.entrySet()) {
            SAVED.setProperty(e.getKey().toString(), Long.toString(e.getValue().ticks));
        }
        try (OutputStream out = Files.newOutputStream(savePath())) {
            SAVED.store(out, "silencio");
        } catch (IOException ignored) {
        }
    }

    private static PlayerState state(ServerPlayerEntity p) {
        return STATES.computeIfAbsent(p.getUuid(), id -> {
            PlayerState s = new PlayerState();
            try {
                s.ticks = Long.parseLong(SAVED.getProperty(id.toString(), "0"));
            } catch (NumberFormatException e) {
                s.ticks = 0;
            }
            s.nextEvent = tick + 20L * 60;
            return s;
        });
    }

    private static int stage(PlayerState st) {
        long minutes = st.ticks / 1200L;
        if (minutes < 5) return 0;
        if (minutes < 14) return 1;
        if (minutes < 28) return 2;
        if (minutes < 45) return 3;
        return 4;
    }

    // ------------------------------------------------------------------ scheduler

    private static void later(int delayTicks, MinecraftServer server, UUID id, Consumer<ServerPlayerEntity> action) {
        TASKS.add(new Task(tick + delayTicks, () -> {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
            if (p != null && !paused) action.accept(p);
        }));
    }

    private static void laterRaw(int delayTicks, Runnable r) {
        TASKS.add(new Task(tick + delayTicks, r));
    }

    // ------------------------------------------------------------------ main tick

    private static void onTick(MinecraftServer server) {
        tick++;

        if (!TASKS.isEmpty()) {
            List<Task> due = new ArrayList<>();
            Iterator<Task> it = TASKS.iterator();
            while (it.hasNext()) {
                Task t = it.next();
                if (t.due() <= tick) {
                    due.add(t);
                    it.remove();
                }
            }
            for (Task t : due) {
                try {
                    t.run().run();
                } catch (Throwable ignored) {
                }
            }
        }

        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.isSpectator() || p.isDead()) continue;
            PlayerState st = state(p);
            st.ticks++;
            if (paused) continue;
            try {
                if (tick % 2 == 0) updateWatcher(p, st);
                if (tick % 20 == 0) director(p, st);
            } catch (Throwable ignored) {
            }
        }

        if (tick % 2400 == 0) saveAll(server);
    }

    private static void director(ServerPlayerEntity p, PlayerState st) {
        int stage = stage(st);
        if (stage == 0) return;

        // acordar com algo ao lado da cama
        if (p.isSleeping() && stage >= 2 && tick - st.lastSleepScare > 20L * 60 * 4 && RNG.nextInt(100) < 6) {
            st.lastSleepScare = tick;
            fireEvent(p, st, 12);
            return;
        }

        if (tick < st.nextEvent) return;
        if (RNG.nextInt(100) >= 20) return;

        int[] pool;
        switch (stage) {
            case 1 -> pool = new int[]{0, 1, 2, 3};
            case 2 -> pool = new int[]{0, 1, 2, 3, 4, 5, 6, 7};
            case 3 -> pool = new int[]{1, 2, 4, 5, 6, 7, 8, 9, 10};
            default -> pool = new int[]{4, 5, 6, 7, 8, 9, 10, 11, 12};
        }
        fireEvent(p, st, pool[RNG.nextInt(pool.length)]);

        int[] lo = {0, 120, 80, 50, 30};
        int[] span = {0, 120, 80, 60, 50};
        st.nextEvent = tick + 20L * (lo[stage] + RNG.nextInt(span[stage]));
    }

    // ------------------------------------------------------------------ events

    private static void fireEvent(ServerPlayerEntity p, PlayerState st, int e) {
        ServerWorld w = p.getServerWorld();
        String name = p.getName().getString();
        switch (e) {
            case 0 -> playAt(w, behind(p, 16, 4), DRONE, 2.0f, 1.0f);
            case 1 -> playAt(w, behind(p, 3, 1), WHISPER, 0.7f, 0.9f + RNG.nextFloat() * 0.2f);
            case 2 -> say(p, pick(LOW_LINES).replace("{n}", name));
            case 3 -> fakeJoin(p);
            case 4 -> footsteps(p);
            case 5 -> {
                if (!torchOut(p)) playAt(w, behind(p, 10, 3), KNOCK, 1.5f, 1.0f);
            }
            case 6 -> {
                if (!openDoor(p)) footsteps(p);
            }
            case 7 -> {
                if (!spawnWatcher(p, st, 22, 30, 0)) playAt(w, behind(p, 4, 2), WHISPER, 0.8f, 1.0f);
            }
            case 8 -> {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 160, 0, false, false, false));
                playAt(w, p.getPos(), HEARTBEAT, 1.4f, 1.0f);
            }
            case 9 -> {
                if (!spawnWatcher(p, st, 13, 18, 0)) playAt(w, behind(p, 2, 1), KNOCK, 1.5f, 0.8f);
            }
            case 10 -> deepChat(p);
            case 11 -> {
                playAt(w, p.getPos(), HEARTBEAT, 1.6f, 0.9f);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 200, 0, false, false, false));
                playAt(w, behind(p, 3, 1), WHISPER, 1.0f, 0.8f);
                UUID id = p.getUuid();
                later(70, p.getServer(), id, pl -> {
                    playAt(pl.getServerWorld(), behind(pl, 2, 1), KNOCK, 1.8f, 0.7f);
                    say(pl, pick(HARD_LINES).replace("{n}", name));
                });
            }
            case 12 -> {
                if (p.isSleeping()) {
                    playAt(w, behind(p, 3, 1), WHISPER, 1.0f, 0.8f);
                    spawnWatcher(p, st, 2.5, 3.5, 140);
                    UUID id = p.getUuid();
                    later(100, p.getServer(), id, pl -> say(pl, "você disse que ia dormir."));
                } else if (!spawnWatcher(p, st, 9, 12, 0)) {
                    playAt(w, behind(p, 2, 1), WHISPER, 1.0f, 0.7f);
                }
            }
            default -> playAt(w, behind(p, 12, 3), KNOCK, 1.5f, 1.0f);
        }
    }

    private static void fakeJoin(ServerPlayerEntity p) {
        p.sendMessage(Text.translatable("multiplayer.player.joined", GHOST).formatted(Formatting.YELLOW));
        MinecraftServer srv = p.getServer();
        if (srv == null) return;
        later(400 + RNG.nextInt(900), srv, p.getUuid(), pl ->
                pl.sendMessage(Text.translatable("multiplayer.player.left", GHOST).formatted(Formatting.YELLOW)));
    }

    private static void deepChat(ServerPlayerEntity p) {
        String name = p.getName().getString();
        int h = LocalTime.now().getHour();
        if (h >= 0 && h < 5 && RNG.nextBoolean()) {
            String t = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
            say(p, "são " + t + ". você deveria estar dormindo.");
        } else {
            say(p, pick(HARD_LINES).replace("{n}", name));
        }
    }

    private static void footsteps(ServerPlayerEntity p) {
        MinecraftServer srv = p.getServer();
        if (srv == null) return;
        int n = 5 + RNG.nextInt(5);
        double lateral = (RNG.nextDouble() - 0.5) * 8;
        long t = 0;
        UUID id = p.getUuid();
        for (int i = 0; i < n; i++) {
            final double dist = 16 - (12.0 * i) / (n - 1);
            final double lat = lateral * (1.0 - (double) i / (n - 1));
            t += 8 + RNG.nextInt(5);
            later((int) t, srv, id, pl -> {
                ServerWorld w = pl.getServerWorld();
                BlockState under = w.getBlockState(pl.getBlockPos().down());
                SoundEvent step = under.isAir() ? SoundEvents.BLOCK_STONE_STEP : under.getSoundGroup().getStepSound();
                playAt(w, behind(pl, dist, 0).add(sideways(pl, lat)), step, 1.3f, 0.85f + RNG.nextFloat() * 0.2f);
            });
        }
    }

    private static boolean torchOut(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        List<BlockPos> found = scan(w, p.getBlockPos(), 12, 5,
                s -> s.isOf(Blocks.TORCH) || s.isOf(Blocks.WALL_TORCH));
        if (found.isEmpty()) return false;
        int count = Math.min(found.size(), 1 + RNG.nextInt(3));
        for (int i = 0; i < count; i++) {
            BlockPos pos = found.remove(RNG.nextInt(found.size()));
            w.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
            w.playSound(null, pos, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.6f, 1.0f);
        }
        return true;
    }

    private static boolean openDoor(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        List<BlockPos> found = scan(w, p.getBlockPos(), 14, 3, s ->
                s.getBlock() instanceof DoorBlock
                        && !s.isOf(Blocks.IRON_DOOR)
                        && s.get(DoorBlock.HALF) == DoubleBlockHalf.LOWER
                        && !s.get(DoorBlock.OPEN));
        if (found.isEmpty()) return false;
        BlockPos pos = found.get(RNG.nextInt(found.size()));
        BlockState s = w.getBlockState(pos);
        ((DoorBlock) s.getBlock()).setOpen(null, w, s, pos, true);
        return true;
    }

    private static List<BlockPos> scan(ServerWorld w, BlockPos c, int r, int ry, Predicate<BlockState> test) {
        List<BlockPos> out = new ArrayList<>();
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                for (int y = -ry; y <= ry; y++) {
                    BlockPos pos = c.add(x, y, z);
                    if (test.test(w.getBlockState(pos))) out.add(pos);
                }
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ watcher

    private static boolean spawnWatcher(ServerPlayerEntity p, PlayerState st, double min, double max, int grace) {
        if (st.watcher != null && !st.watcher.isRemoved()) return false;
        ServerWorld w = p.getServerWorld();
        for (int i = 0; i < 16; i++) {
            double d = min + RNG.nextDouble() * (max - min);
            double ang = Math.toRadians(p.getYaw() + (RNG.nextDouble() - 0.5) * 140.0);
            double x = p.getX() - Math.sin(ang) * d;
            double z = p.getZ() + Math.cos(ang) * d;
            BlockPos g = findGround(w, MathHelper.floor(x), p.getBlockY(), MathHelper.floor(z));
            if (g == null) continue;
            if (i < 10 && w.getLightLevel(g) > 7) continue; // prefere o escuro
            VillagerEntity v = EntityType.VILLAGER.create(w);
            if (v == null) return false;
            v.refreshPositionAndAngles(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, 0.0f, 0.0f);
            v.setAiDisabled(true);
            v.setSilent(true);
            v.setInvulnerable(true);
            v.setPersistent();
            w.spawnEntity(v);
            st.watcher = v;
            st.watcherAge = 0;
            st.grace = grace;
            st.lookTicks = 0;
            face(v, p);
            return true;
        }
        return false;
    }

    private static BlockPos findGround(ServerWorld w, int x, int y, int z) {
        for (int dy = 4; dy >= -8; dy--) {
            BlockPos pos = new BlockPos(x, y + dy, z);
            BlockPos below = pos.down();
            if (w.getBlockState(pos).isAir() && w.getBlockState(pos.up()).isAir()
                    && w.getBlockState(below).isSolidBlock(w, below)) {
                return pos;
            }
        }
        return null;
    }

    private static void face(VillagerEntity v, ServerPlayerEntity p) {
        double dx = p.getX() - v.getX();
        double dz = p.getZ() - v.getZ();
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        v.setYaw(yaw);
        v.setHeadYaw(yaw);
        v.setBodyYaw(yaw);
    }

    private static void updateWatcher(ServerPlayerEntity p, PlayerState st) {
        VillagerEntity v = st.watcher;
        if (v == null) return;
        if (v.isRemoved() || v.getWorld() != p.getWorld()) {
            dropWatcher(st);
            return;
        }
        st.watcherAge += 2;
        face(v, p);

        double dist = v.distanceTo(p);
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d to = v.getEyePos().subtract(p.getEyePos()).normalize();
        double dot = look.dotProduct(to);
        boolean looking = dot > 0.95 && p.canSee(v);

        if (looking) st.lookTicks += 2;
        else st.lookTicks = Math.max(0, st.lookTicks - 1);

        ServerWorld w = p.getServerWorld();

        if (looking && st.lookTicks >= 34) {
            playAt(w, p.getPos(), HEARTBEAT, 1.2f, 1.0f);
            if (RNG.nextInt(100) < 35) say(p, "você olhou.");
            dropWatcher(st);
            return;
        }
        if (!looking && st.watcherAge > st.grace && dist < 5.5) {
            dropWatcher(st);
            UUID id = p.getUuid();
            later(30 + RNG.nextInt(30), p.getServer(), id, pl ->
                    playAt(pl.getServerWorld(), behind(pl, 2, 1), KNOCK, 1.6f, 0.8f));
            return;
        }
        if (st.watcherAge > 3600) {
            dropWatcher(st);
            return;
        }

        // aproxima-se quando você não esta olhando
        if (dot < 0.3 && st.watcherAge % 40 == 0 && dist > 7 && st.watcherAge > st.grace) {
            double dx = p.getX() - v.getX();
            double dz = p.getZ() - v.getZ();
            double len = Math.max(0.001, Math.sqrt(dx * dx + dz * dz));
            double step = 1.5 + RNG.nextDouble() * 1.5;
            double nx = v.getX() + dx / len * step;
            double nz = v.getZ() + dz / len * step;
            BlockPos g = findGround(w, MathHelper.floor(nx), MathHelper.floor(v.getY()), MathHelper.floor(nz));
            if (g != null) {
                v.refreshPositionAndAngles(nx, g.getY(), nz, v.getYaw(), 0.0f);
                face(v, p);
            }
        }
    }

    private static void dropWatcher(PlayerState st) {
        if (st.watcher != null) {
            if (!st.watcher.isRemoved()) st.watcher.discard();
            st.watcher = null;
        }
        st.lookTicks = 0;
        st.watcherAge = 0;
    }

    // ------------------------------------------------------------------ sound / geometry helpers

    private static Vec3d behind(ServerPlayerEntity p, double dist, double jitter) {
        Vec3d f = Vec3d.fromPolar(0.0f, p.getYaw());
        double jx = (RNG.nextDouble() - 0.5) * 2 * jitter;
        double jz = (RNG.nextDouble() - 0.5) * 2 * jitter;
        return p.getPos().add(f.multiply(-dist)).add(jx, 0, jz);
    }

    private static Vec3d sideways(ServerPlayerEntity p, double amount) {
        Vec3d f = Vec3d.fromPolar(0.0f, p.getYaw());
        return new Vec3d(-f.z, 0, f.x).multiply(amount);
    }

    private static void playAt(ServerWorld w, Vec3d pos, SoundEvent s, float vol, float pitch) {
        w.playSound(null, pos.x, pos.y, pos.z, s, SoundCategory.AMBIENT, vol, pitch);
    }

    // ------------------------------------------------------------------ chat

    private static void say(ServerPlayerEntity p, String msg) {
        p.sendMessage(Text.literal("<" + GHOST + "> " + msg));
    }

    private static String pick(String[] arr) {
        return arr[RNG.nextInt(arr.length)];
    }

    private static boolean has(String text, String... keys) {
        String[] words = text.split("[^\\p{L}0-9]+");
        for (String k : keys) {
            if (k.length() <= 3) {
                for (String w : words) if (w.equals(k)) return true;
            } else if (text.contains(k)) {
                return true;
            }
        }
        return false;
    }

    private static void onChat(ServerPlayerEntity sender, String content) {
        if (paused || content == null) return;
        MinecraftServer srv = sender.getServer();
        if (srv == null) return;
        PlayerState st = state(sender);
        int stage = stage(st);
        String text = content.trim().toLowerCase();
        boolean called = text.contains("observador");

        if (stage == 0 && !called) return;
        int chance = called ? 100 : stage == 1 ? 30 : stage == 2 ? 50 : 70;
        if (RNG.nextInt(100) >= chance) return;

        String name = sender.getName().getString();
        String[] pool = null;
        if (has(text, "oi", "ola", "olá", "hello", "hi", "eae", "opa")) pool = R_HELLO;
        else if (has(text, "quem", "who", "você e", "você é")) pool = R_WHO;
        else if (has(text, "medo", "assust", "scared", "afraid", "ai meu deus")) pool = R_FEAR;
        else if (has(text, "herobrine", "entity", "notch", "303")) pool = R_HERO;
        else if (has(text, "onde", "where", "aparece")) pool = R_WHERE;
        else if (has(text, "sai", "vai embora", "go away", "leave", "para com")) pool = R_LEAVE;
        else if (has(text, "mod", "bug", "script", "codigo", "código", "code", "dev")) pool = R_MOD;
        else if (has(text, "ajuda", "help", "socorro")) pool = R_HELP;
        else if (has(text, "dormir", "sleep", "cama", "bed")) pool = R_SLEEP;
        else if (has(text, "kkk", "haha", "lol", "rs")) pool = R_LAUGH;
        else if (called) pool = R_CALLED;
        else if (stage >= 2 && RNG.nextInt(100) < 45) pool = R_ANY;

        String reply;
        if (pool != null) {
            reply = pick(pool).replace("{n}", name);
        } else if (stage >= 3 && RNG.nextInt(100) < 25) {
            reply = new StringBuilder(content.trim()).reverse().toString();
        } else {
            return;
        }

        final String out = reply;
        later(35 + RNG.nextInt(80), srv, sender.getUuid(), pl -> {
            say(pl, out);
            if (stage >= 3 && RNG.nextInt(100) < 25) playAt(pl.getServerWorld(), behind(pl, 3, 1), WHISPER, 0.8f, 1.0f);
        });
    }

    // ------------------------------------------------------------------ texts

    private static final String[] LOW_LINES = {
            "você está aí?",
            "{n}.",
            "tem alguém aqui além de você.",
            "você não devia ter vindo sozinho.",
            "eu estava esperando."
    };

    private static final String[] HARD_LINES = {
            "{n}, olhe atrás de você.",
            "eu vi o que você fez.",
            "você acha que o jogo acaba quando você sai?",
            "eu conheço o som dos seus passos.",
            "não corra. eu fico mais perto quando você corre.",
            "você sempre olha tarde demais.",
            "eu estou mais perto do que a última vez."
    };

    private static final String[] JOIN_LINES = {
            "voltou.",
            "demorou, {n}.",
            "eu não saí daqui."
    };

    private static final String[] DEATH_LINES = {
            "eu avisei.",
            "isso não doeu. dessa vez.",
            "de novo, {n}."
    };

    private static final String[] R_HELLO = {"{n}.", "você demorou.", "eu estava esperando você falar."};
    private static final String[] R_WHO = {"você sabe quem eu sou. só não quer dizer em voz alta.", "alguém que sobrou.", "pergunte de novo quando estiver escuro."};
    private static final String[] R_FEAR = {"bom.", "continue.", "ainda não."};
    private static final String[] R_HERO = {"ele não está aqui. só eu.", "sempre me confundem com outros."};
    private static final String[] R_WHERE = {"atrás de você? não. ainda não.", "mais perto do que você imagina."};
    private static final String[] R_LEAVE = {"você pode fechar o jogo. eu espero.", "você não vai fechar. eu sei."};
    private static final String[] R_MOD = {"isso aqui não foi escrito para você.", "alguém esqueceu de apagar a linha onde eu estou."};
    private static final String[] R_HELP = {"ninguém ouve daqui.", "eu ouço. isso conta?"};
    private static final String[] R_SLEEP = {"feche os olhos. eu fico de guarda.", "não durma."};
    private static final String[] R_LAUGH = {"ri enquanto pode.", "isso. ri."};
    private static final String[] R_CALLED = {"sim?", "você me chamou.", "não me chame se não quer a resposta."};
    private static final String[] R_ANY = {"{n}.", "eu li isso.", "escreva de novo. mais devagar.", "você digita rápido quando está nervoso."};
}
