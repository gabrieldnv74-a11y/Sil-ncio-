# Silêncio (Fabric 1.21.1)

Requer: Minecraft 1.21.1, Fabric Loader 0.16+, Fabric API (1.21.1), Java 21.
Instale: coloque `silencio-1.0.0.jar` e o Fabric API na pasta `mods`.
Jogue normalmente. Dê tempo ao jogo.

Se precisar parar: `/silencio parar` (e `/silencio retomar`).
